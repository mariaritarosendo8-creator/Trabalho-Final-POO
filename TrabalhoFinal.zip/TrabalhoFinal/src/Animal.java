public class Animal {
    private String id;
    private String nome;
    private String especie;
    private String raca;
    private String porte;
    private int idade;
    private String estadoSaude;
    private String dataResgate;
    private String statusAdocao;
    private boolean estadoCritico;

    public Animal(String id, String nome, String especie, String raca, String porte, int idade, String estadoSaude, String dataResgate, String statusAdocao, boolean estadoCritico) {
        this.id = id;
        this.nome = nome;
        this.especie = especie;
        this.raca = raca;
        this.porte = porte;
        this.idade = idade;
        this.estadoSaude = estadoSaude;
        this.dataResgate = dataResgate;
        this.statusAdocao = statusAdocao;
        this.estadoCritico = estadoCritico;
    }

    public String getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEspecie() {
        return especie;
    }

    public String getRaca() {
        return raca;
    }

    public int getIdade() {
        return idade;
    }

    public String getPorte() {
        return porte;
    }

    public String getEstadoSaude() {
        return estadoSaude;
    }

    public String getDataResgate() {
        return dataResgate;
    }

    public String getStatusAdocao() {
        return statusAdocao;
    }

    public void setStatusAdocao(String statusAdocao) {
    this.statusAdocao = statusAdocao;
}

    public boolean getEstadoCritico() {
        return estadoCritico;
    }
    
}
