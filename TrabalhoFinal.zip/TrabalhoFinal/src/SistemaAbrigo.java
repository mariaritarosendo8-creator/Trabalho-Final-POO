import java.util.ArrayList;
import java.util.List;

public class SistemaAbrigo {
    private List<Animal> animais = new ArrayList<>();
    private List<Usuario> historicoVacinas = new ArrayList<>();

    public void adicionarAnimal(Animal animal) {
        animais.add(animal);
    }

    public void registrarVacina(Animal animal, String vacina, String data, Object ursuarioLogado) throws VacinacaoDuplicadaException, PermicaoNegadaException {
        if(!(usuarioLogado instanceof Veterinario)) {
            throw new PermissaoNegadaException("Apenas veterinários podem registrar vacinas.");
        }

        String registroChave = animal.getId() + "-" + vacina + "-" + data;
        if(historicoVacinas.contains(registroChave)) {
            throw new VacinacaoDuplicadaException("Vacina já registrada para este animal na mesma data.");
        }
        historicoVacinas.add(registroChave);
        System.out.println("Vacina " + vacina + " aplicada com sucesso em " + animal.getNome() + " na data " + data + ".");
    }

    public void solicitarAdocao(Animal animal) throws AnimalIndisponivelException {
        if(animal.isEstadoCritico() || !animal.getStatusAdocao().equalsIgnoreCase("Disponivel")) {
            throw new AnimalIndisponivelException("Animal não disponível para adoção.");
        }
        System.out.println(usuario.getNome() + " solicitou a adoção de " + animal.getNome() + ".");
    }

    public void aprovarAdocao(Animal animal, Object usuarioLogado) throws PermissaoNegadaException, AnimalIndisponivelException {
        if(!(usuarioLogado instanceof Administrador)) {
            throw new PermissaoNegadaException("Apenas administradores podem aprovar adoções.");
        }
        if(!animal.getStatusAdocao().equalsIgnoreCase("Disponivel")) {
            throw new AnimalIndisponivelException("Animal não disponível para adoção.");
        }
        animal.setStatusAdocao("Adotado");
        System.out.println("Adoção de " + animal.getNome() + " aprovada com sucesso.");
    }
}