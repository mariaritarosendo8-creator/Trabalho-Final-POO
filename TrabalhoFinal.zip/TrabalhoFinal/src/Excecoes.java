class AnimalIndisponivelException extends Exception {
    public AnimalIndisponivelException(String mensagem){
        super(mensagem);
    }    
}

class VacinacaoDuplicadaException extends Exception {
     public VacinacaoDuplicadaException(String mensagem){
        super(mensagem);
    }    
}

class PermissaoNegadaException extends Exception {
     public PermissaoNegadaException(String mensagem){
        super(mensagem);
    }    
}
