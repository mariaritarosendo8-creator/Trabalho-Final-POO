class AnimalIndisponivel extends Exception {
    AnimalIndisponivel(String mensagem){
        super(mensagem);
    }    
}

class VacinacaoDuplicadaException extends Exception {
     VacinacaoDuplicadaException(String mensagem){
        super(mensagem);
    }    
}

class PermicaoNegadaException extends Exception {
     PermicaoNegadaException(String mensagem){
        super(mensagem);
    }    
}
