import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static List<Animal> animais = new ArrayList<>();
    private static List<Usuario> usuarios = new ArrayList<>();
    private static List<String> historicoVacinas = new ArrayList<>();
    private static List<String> notificacoesSistema = new ArrayList<>();

    public static void main(String[] args) {
        animais.add(new Animal("01", "Mel", "Gato", "SRD", "Pequeno", 2, "Saudável e Vacinado", "10/01/2026", "Disponível", false));
        animais.add(new Animal("02", "Thor", "Cão", "Labrador", "Grande", 4, "Tratamento intensivo de cinomose", "15/04/2026", "Indisponível", true));
        animais.add(new Animal("03", "Nina", "Cão", "Poodle", "Médio", 1, "Saudável", "20/04/2026", "Disponível", false));

        Administrador admin = new Administrador("Adm Niquel", "a1", "admin@abrigo.com", "123");
        Veterinario vet = new Veterinario("Doutora Geciara", "v1", "vet@abrigo.com", "123", "CRMV-CE 1234");
        Voluntario voluntario = new Voluntario("Maria Rita", "u1", "maria@vol.com", "123");

        usuarios.add(admin);
        usuarios.add(vet);
        usuarios.add(voluntario);

        notificacoesSistema.add("[!] Novo animal cadastrado: Nina");
        notificacoesSistema.add("[!] Próximo evento: Feira de Adoção neste domingo.");

        boolean rodando = true;
        while (rodando) {
            String[] opcoesLoginWeb = {
                "Entrar com E-mail e Senha", 
                "Cadastrar Novo Usuário (Voluntário / Veterinário)", 
                "Visualizar Animais Disponíveis (Catálogo Público)", 
                "Ver Notificações do Abrigo",
                "Sair do Sistema"
            };

            int escolha = JOptionPane.showOptionDialog(
                null,
                "====================================================\n" +
                "         SISTEMA DE ABRIGOS E RESGATES DE ANIMAIS   \n" +
                "====================================================\n\n" +
                "Selecione uma opção para navegar no sistema:",
                "PORTAL DO ABRIGO - HOME",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                opcoesLoginWeb,
                opcoesLoginWeb[0]
            );

            if (escolha == -1 || escolha == 4) {
                JOptionPane.showMessageDialog(null, "Obrigado por utilizar o Sistema de Abrigos!\nEsperamos vê-lo novamente!", "Encerrando", JOptionPane.INFORMATION_MESSAGE);
                rodando = false;
                break;
            }

            switch (escolha) {
                case 0:
                    fazerLogin();
                    break;
                case 1:
                    cadastrarNovoUsuario();
                    break;
                case 2:
                    listarAnimaisPublico();
                    break;
                case 3:
                    exibirNotificacoes();
                    break;
            }
        }
    }

    private static void fazerLogin() {
        String email = JOptionPane.showInputDialog(null, "Digite o seu e-mail de acesso:", "Login no Sistema", JOptionPane.QUESTION_MESSAGE);
        if (email == null) return;

        String senha = JOptionPane.showInputDialog(null, "Digite a sua senha:", "Login no Sistema", JOptionPane.QUESTION_MESSAGE);
        if (senha == null) return;

        Usuario usuarioLogado = null;
        for (Usuario u : usuarios) {
            if (u.getEmail().equals(email) && u.getSenha().equals(senha)) {
                usuarioLogado = u;
                break;
            }
        }

        if (usuarioLogado != null) {
            JOptionPane.showMessageDialog(null, "Login bem-sucedido!\nBem-vindo(a), " + usuarioLogado.getNome(), "Autenticação Autorizada", JOptionPane.INFORMATION_MESSAGE);
            usuarioLogado.exibirMenu();

            if (usuarioLogado instanceof Administrador) {
                painelAdministrador((Administrador) usuarioLogado);
            } else if (usuarioLogado instanceof Veterinario) {
                painelVeterinario((Veterinario) usuarioLogado);
            } else if (usuarioLogado instanceof Voluntario) {
                painelVoluntario((Voluntario) usuarioLogado);
            }
        } else {
            JOptionPane.showMessageDialog(null, "E-mail ou senha incorretos!", "Erro de Acesso", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void cadastrarNovoUsuario() {
        String[] tipos = {"Voluntário", "Veterinário"};
        int tipoEscolhido = JOptionPane.showOptionDialog(null, "Escolha o perfil de cadastro:", "Cadastro de Novo Usuário",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, tipos, tipos[0]);

        if (tipoEscolhido == -1) return;

        String nome = JOptionPane.showInputDialog("Nome completo:");
        if (nome == null || nome.isEmpty()) return;
        String id = "u" + (usuarios.size() + 1);
        String email = JOptionPane.showInputDialog("E-mail:");
        if (email == null || email.isEmpty()) return;
        String senha = JOptionPane.showInputDialog("Senha:");
        if (senha == null || senha.isEmpty()) return;

        if (tipoEscolhido == 0) {
            Voluntario novoVol = new Voluntario(nome, id, email, senha);
            usuarios.add(novoVol);
            JOptionPane.showMessageDialog(null, "Voluntário cadastrado com sucesso! Faça login para acessar.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String crmv = JOptionPane.showInputDialog("Informe o CRMV (Ex: CRMV-CE 5678):");
            if (crmv == null) crmv = "CRMV-CE 0000";
            Veterinario novoVet = new Veterinario(nome, id, email, senha, crmv);
            usuarios.add(novoVet);
            JOptionPane.showMessageDialog(null, "Veterinário cadastrado com sucesso! Faça login para acessar.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private static void painelVoluntario(Voluntario vol) {
        boolean ativo = true;
        while (ativo) {
            String[] menu = {
                "1. Visualizar Animais Disponíveis para Adoção",
                "2. Solicitar Adoção de um Animal",
                "3. Candidatar-se a Atividades de Apoio (Eventos)",
                "4. Acompanhar Animais sob Minha Responsabilidade",
                "5. Ver Histórico de Participações em Ações da ONG",
                "6. Notificações",
                "0. Fazer Logout (Sair da Conta)"
            };

            int opcao = JOptionPane.showOptionDialog(null, "=== PAINEL DO VOLUNTÁRIO: " + vol.getNome() + " ===", "Área do Voluntário",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, menu, menu[0]);

            if (opcao == -1 || opcao == 6) {
                ativo = false;
                break;
            }

            switch (opcao) {
                case 0:
                    listarAnimaisPublico();
                    break;
                case 1:
                    solicitarAdocaoVoluntario(vol);
                    break;
                case 2:
                    String evento = JOptionPane.showInputDialog("Escolha a atividade de apoio:\n1. Mutirão de Limpeza\n2. Campanha de Vacinação\n3. Feira de Adoção\nDigite o nome do evento:");
                    if (evento != null && !evento.isEmpty()) {
                        vol.adicionarParticipacao(evento + " (Inscrito recentemente)");
                        JOptionPane.showMessageDialog(null, "Inscrição realizada com sucesso na atividade: " + evento, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    }
                    break;
                case 3:
                    StringBuilder sbAnimais = new StringBuilder("=== ANIMAIS SOB SUA RESPONSABILIDADE ===\n\n");
                    for (String a : vol.getAnimaisAcompanhados()) {
                        sbAnimais.append("- ").append(a).append("\n");
                    }
                    JOptionPane.showMessageDialog(null, sbAnimais.toString(), "Acompanhamento", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 4:
                    StringBuilder sbHist = new StringBuilder("=== HISTÓRICO DE PARTICIPAÇÕES ===\n\n");
                    for (String h : vol.getHistoricoParticipacao()) {
                        sbHist.append("✓ ").append(h).append("\n");
                    }
                    JOptionPane.showMessageDialog(null, sbHist.toString(), "Histórico da ONG", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 5:
                    exibirNotificacoes();
                    break;
            }
        }
    }

    private static void solicitarAdocaoVoluntario(Voluntario vol) {
        String idAnimal = JOptionPane.showInputDialog("Digite o ID do animal que deseja solicitar adoção:");
        if (idAnimal == null) return;

        Animal animalAlvo = null;
        for (Animal a : animais) {
            if (a.getId().equals(idAnimal)) {
                animalAlvo = a;
                break;
            }
        }

        try {
            if (animalAlvo == null) {
                throw new AnimalIndisponivelException("Erro: Animal com ID " + idAnimal + " não encontrado.");
            }
            if (animalAlvo.getEstadoCritico() || !animalAlvo.getStatusAdocao().equalsIgnoreCase("Disponível")) {
                throw new AnimalIndisponivelException("Solicitação negada: O animal " + animalAlvo.getNome() + " está em tratamento crítico ou indisponível!");
            }

            vol.adicionarAnimalAcompanhado(animalAlvo.getNome() + " (" + animalAlvo.getEspecie() + ")");
            JOptionPane.showMessageDialog(null, "Solicitação de adoção enviada com sucesso para o animal " + animalAlvo.getNome() + "!\nAguarde a aprovação do Administrador.", "Sucesso na Adoção", JOptionPane.INFORMATION_MESSAGE);

        } catch (AnimalIndisponivelException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "VIOLAÇÃO DE REGRA DE NEGÓCIO", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void painelVeterinario(Veterinario vet) {
        boolean ativo = true;
        while (ativo) {
            String[] menu = {
                "1. Consultar Animais e Prontuários",
                "2. Registrar Consultas e Tratamentos",
                "3. Atualizar Informações Médicas dos Animais",
                "4. Registrar Vacinação (Testar Regra RN2)",
                "5. Emitir Relatório de Saúde",
                "6. Notificações",
                "0. Fazer Logout (Sair da Conta)"
            };

            int opcao = JOptionPane.showOptionDialog(null, "=== PAINEL DO VETERINÁRIO: " + vet.getNome() + " ===", "Área do Veterinário",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, menu, menu[0]);

            if (opcao == -1 || opcao == 6) {
                ativo = false;
                break;
            }

            switch (opcao) {
                case 0:
                    listarProntuariosVeterinario();
                    break;
                case 1:
                    registrarTratamento(vet);
                    break;
                case 2:
                    atualizarInformacoesMedicas(vet);
                    break;
                case 3:
                    registrarVacina(vet);
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, 
                        "=== RELATÓRIO DE SAÚDE DO ABRIGO ===\n" +
                        "Total de Animais Monitorados: " + animais.size() + "\n" +
                        "Animais Saudáveis: 2\n" +
                        "Animais em Tratamento Crítico (Isolados): 1 (Thor)\n" +
                        "Campanhas de Vacinação Ativas: 1", 
                        "Relatório Médico", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 5:
                    exibirNotificacoes();
                    break;
            }
        }
    }

    private static void listarProntuariosVeterinario() {
        StringBuilder sb = new StringBuilder("=== PRONTUÁRIOS MÉDICOS ===\n\n");
        for (Animal a : animais) {
            sb.append("ID: ").append(a.getId())
              .append(" | Nome: ").append(a.getNome())
              .append(" | Saúde: ").append(a.getEstadoSaude())
              .append(" | Crítico: ").append(a.getEstadoCritico() ? "Sim" : "Não")
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Prontuários", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void registrarTratamento(Veterinario vet) {
        String idAnimal = JOptionPane.showInputDialog("Digite o ID do animal para registrar atendimento:");
        if (idAnimal == null) return;

        Animal animalAlvo = null;
        for (Animal a : animais) {
            if (a.getId().equals(idAnimal)) {
                animalAlvo = a;
                break;
            }
        }

        if (animalAlvo == null) {
            JOptionPane.showMessageDialog(null, "Animal não encontrado!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String tratamento = JOptionPane.showInputDialog("Descrição da Consulta / Tratamento:");
        if (tratamento == null) return;

        JOptionPane.showMessageDialog(null, "Atendimento registrado com sucesso pelo Dr(a). " + vet.getNome() + " para o animal " + animalAlvo.getNome() + ".", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void atualizarInformacoesMedicas(Veterinario vet) {
        String idAnimal = JOptionPane.showInputDialog("Digite o ID do animal para atualizar prontuário:");
        if (idAnimal == null) return;

        Animal animalAlvo = null;
        for (Animal a : animais) {
            if (a.getId().equals(idAnimal)) {
                animalAlvo = a;
                break;
            }
        }

        try {
            if (animalAlvo == null) throw new AnimalIndisponivelException("Animal não encontrado.");

            String novoEstado = JOptionPane.showInputDialog("Novo estado de saúde:", animalAlvo.getEstadoSaude());
            if (novoEstado == null) return;

            String criticoStr = JOptionPane.showInputDialog("O animal está em tratamento crítico? (sim/nao):");
            animalAlvo.setEstadoSaude(novoEstado);
            if (criticoStr != null && criticoStr.equalsIgnoreCase("sim")) {
                animalAlvo.setEstadoCritico(true);
                animalAlvo.setStatusAdocao("Indisponível");
            } else if (criticoStr != null && criticoStr.equalsIgnoreCase("nao")) {
                animalAlvo.setEstadoCritico(false);
                animalAlvo.setStatusAdocao("Disponível");
            }

            JOptionPane.showMessageDialog(null, "Informações médicas atualizadas com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

        } catch (AnimalIndisponivelException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void registrarVacina(Veterinario vet) {
        String idAnimal = JOptionPane.showInputDialog("ID do animal para vacinar:");
        if (idAnimal == null) return;

        Animal animalAlvo = null;
        for (Animal a : animais) {
            if (a.getId().equals(idAnimal)) {
                animalAlvo = a;
                break;
            }
        }

        if (animalAlvo == null) {
            JOptionPane.showMessageDialog(null, "Animal não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nomeVacina = JOptionPane.showInputDialog("Nome da Vacina (Ex: V10, Antirrábica):");
        if (nomeVacina == null) return;

        String dataApp = JOptionPane.showInputDialog("Data da Aplicação (Ex: 17/11/2026):");
        if (dataApp == null) return;

        try {
            String chave = animalAlvo.getId() + "-" + nomeVacina + "-" + dataApp;
            if (historicoVacinas.contains(chave)) {
                throw new VacinacaoDuplicadaException("Erro (RN2): A vacina " + nomeVacina + " já foi aplicada neste animal na data " + dataApp + "!");
            }

            historicoVacinas.add(chave);
            JOptionPane.showMessageDialog(null, "Vacina " + nomeVacina + " aplicada com sucesso pelo Dr(a). " + vet.getNome() + "!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

        } catch (VacinacaoDuplicadaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "VIOLAÇÃO DE REGRA DE NEGÓCIO", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void painelAdministrador(Administrador admin) {
        boolean ativo = true;
        while (ativo) {
            String[] menu = {
                "1. Gerenciar Animais (Cadastrar / Editar / Remover)",
                "2. Gerenciar Usuários do Sistema",
                "3. Aprovar ou Rejeitar Adoções (Testar Regra RN5)",
                "4. Relatórios Completos e Estatísticas Gerais",
                "5. Notificações",
                "0. Fazer Logout (Sair da Conta)"
            };

            int opcao = JOptionPane.showOptionDialog(null, "=== PAINEL DO ADMINISTRADOR: " + admin.getNome() + " ===", "Área do Administrador",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, menu, menu[0]);

            if (opcao == -1 || opcao == 5) {
                ativo = false;
                break;
            }

            switch (opcao) {
                case 0:
                    gerenciarAnimaisAdmin();
                    break;
                case 1:
                    StringBuilder sbUsr = new StringBuilder("=== USUÁRIOS CADASTRADOS ===\n\n");
                    for (Usuario u : usuarios) {
                        sbUsr.append("- ").append(u.getNome()).append(" (").append(u.getClass().getSimpleName()).append(" | ").append(u.getEmail()).append(")\n");
                    }
                    JOptionPane.showMessageDialog(null, sbUsr.toString(), "Gestão de Usuários", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 2:
                    aprovarAdocoesAdmin();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, 
                        "=== RELATÓRIOS E ESTATÍSTICAS GERAIS ===\n" +
                        "• Total de Animais Resgatados: " + animais.size() + "\n" +
                        "• Adoções Realizadas com Sucesso: 97\n" +
                        "• Espécie Mais Resgatada: Cães (65%)\n" +
                        "• Taxa de Adoção Mensal: 52%\n" +
                        "• Número de Voluntários Ativos: 41\n" +
                        "• Animais Atualmente em Tratamento: 1", 
                        "Estatísticas do Abrigo", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 4:
                    exibirNotificacoes();
                    break;
            }
        }
    }

    private static void gerenciarAnimaisAdmin() {
        String[] opcoesAnimais = {"Cadastrar Novo Animal", "Remover Animal", "Voltar"};
        int escolha = JOptionPane.showOptionDialog(null, "Gerenciamento de Animais", "Admin", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opcoesAnimais, opcoesAnimais[0]);

        if (escolha == 0) {
            String id = JOptionPane.showInputDialog("ID do Animal:");
            if (id == null) return;
            String nome = JOptionPane.showInputDialog("Nome:");
            if (nome == null) return;
            String especie = JOptionPane.showInputDialog("Espécie (Cão / Gato / Outros):");
            if (especie == null) return;
            String raca = JOptionPane.showInputDialog("Raça:");
            if (raca == null) return;
            String porte = JOptionPane.showInputDialog("Porte (Pequeno / Médio / Grande):");
            if (porte == null) return;
            String saude = JOptionPane.showInputDialog("Estado de Saúde:");
            if (saude == null) return;
            
            animais.add(new Animal(id, nome, especie, raca, porte, 2, saude, "17/11/2026", "Disponível", false));
            notificacoesSistema.add("[!] Novo animal cadastrado: " + nome);
            JOptionPane.showMessageDialog(null, "Animal cadastrado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } else if (escolha == 1) {
            String idRemover = JOptionPane.showInputDialog("Digite o ID do animal que deseja remover:");
            if (idRemover == null) return;
            
            Animal paraRemover = null;
            for (Animal a : animais) {
                if (a.getId().equals(idRemover)) {
                    paraRemover = a;
                    break;
                }
            }

            try {
                if (paraRemover == null) throw new AnimalIndisponivelException("Animal não encontrado.");
                if (paraRemover.getStatusAdocao().equalsIgnoreCase("Adotado")) {
                    throw new AnimalIndisponivelException("Erro (RN1): Um animal adotado não pode ser removido do histórico do abrigo!");
                }
                animais.remove(paraRemover);
                JOptionPane.showMessageDialog(null, "Animal removido com sucesso do sistema.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            } catch (AnimalIndisponivelException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "VIOLAÇÃO DE REGRA DE NEGÓCIO", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void aprovarAdocoesAdmin() {
        String idAnimal = JOptionPane.showInputDialog("Digite o ID do animal cuja adoção deseja aprovar:");
        if (idAnimal == null) return;

        Animal animalAlvo = null;
        for (Animal a : animais) {
            if (a.getId().equals(idAnimal)) {
                animalAlvo = a;
                break;
            }
        }

        try {
            if (animalAlvo == null) throw new AnimalIndisponivelException("Animal não encontrado.");
            
            if (animalAlvo.getEstadoCritico() || !animalAlvo.getStatusAdocao().equalsIgnoreCase("Disponível")) {
                throw new AnimalIndisponivelException("Adoção negada: Este animal está em tratamento crítico ou indisponível.");
            }

            animalAlvo.setStatusAdocao("Adotado");
            JOptionPane.showMessageDialog(null, "Adoção do animal " + animalAlvo.getNome() + " aprovada com sucesso pelo Administrador!", "Adoção Concluída", JOptionPane.INFORMATION_MESSAGE);

        } catch (AnimalIndisponivelException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "VIOLAÇÃO DE REGRA DE NEGÓCIO", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void listarAnimaisPublico() {
        StringBuilder sb = new StringBuilder("=========================================\n");
        sb.append("           ANIMAIS DISPONÍVEIS          \n");
        sb.append("=========================================\n\n");
        for (Animal a : animais) {
            sb.append("ID: ").append(a.getId())
              .append(" | Nome: ").append(a.getNome())
              .append(" | Espécie: ").append(a.getEspecie())
              .append(" | Raça: ").append(a.getRaca())
              .append(" | Status: ").append(a.getStatusAdocao())
              .append(" | Crítico: ").append(a.getEstadoCritico() ? "Sim" : "Não")
              .append("\n-----------------------------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Catálogo de Animais", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void exibirNotificacoes() {
        StringBuilder sb = new StringBuilder("=== NOTIFICAÇÕES DO ABRIGO ===\n\n");
        for (String n : notificacoesSistema) {
            sb.append(n).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Central de Notificações", JOptionPane.INFORMATION_MESSAGE);
    }
}