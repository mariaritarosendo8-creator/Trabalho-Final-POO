import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Olá, Mundo!");

        String nome = JOptionPane.showInputDialog("Qual é o seu nome?");
        
        JOptionPane.showMessageDialog(null, "Bem-vindo, " + nome);
    }
}
