import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static List<Animal> animais = new ArrayList<>();
    private static List<String> historicoVacinas = new ArrayList<>();
    
    private static Administrador admin = new Administrador("Adm Niquel", "a1", "admin@abrigo.com", "123");
    private static Veterinario vet = new Veterinario("Doutora Geciara", "v1", "vet@abrigo.com", "123", "CRMV-CE 1234");
    private static Voluntario voluntario = new Voluntario("Maria Rita", "u1", "maria@vol.com", "123");

    public static void main(String[] args) {
        animais.add(new Animal("01", "yoru", "Gato", "SRD", "Pequeno", 2, "Saudável", "10/01/2026", "Disponível", false));
        animais.add(new Animal("02", "Luna", "Cão", "Labrador", "Grande", 4, "Em tratamento", "15/04/2026", "Disponível", true));

        boolean rodando = true;

        while (rodando) {
            String[] opcoesMenuPrincipal = {
                "1. Fazer Login / Área de Perfis",
                "2. Visualizar Animais Disponíveis",
                "3. Testar Regras de Negócio e Exceções",
                "0. Sair do Sistema"
            };

            int escolha = JOptionPane.showOptionDialog(
                null,
                "==================================================\n" +
                "   SISTEMA DE GERENCIAMENTO DE ABRIGOS E RESGATES   \n" +
                "==================================================",
                "MENU PRINCIPAL",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                opcoesMenuPrincipal,
                opcoesMenuPrincipal[0]
            );

            if (escolha == -1 || escolha == 3) {
                JOptionPane.showMessageDialog(null, "Obrigado por utilizar o Sistema de Abrigos!", "Encerrando", JOptionPane.INFORMATION_MESSAGE);
                rodando = false;
                break;
            }

            switch (escolha) {
                case 0:
                    fazerLogin();
                    break;
                case 1:
                    listarAnimais();
                    break;
                case 2:
                    executarTestesDeExcecoes();
                    break;
            }
        }
    }

    private static void fazerLogin() {
        String email = JOptionPane.showInputDialog(null, "Digite o e-mail de acesso:", "LOGIN", JOptionPane.QUESTION_MESSAGE);
        if (email == null) return;

        String senha = JOptionPane.showInputDialog(null, "Digite a senha:", "LOGIN", JOptionPane.QUESTION_MESSAGE);
        if (senha == null) return;

        if (email.equals(admin.getEmail()) && senha.equals(admin.getSenha())) {
            JOptionPane.showMessageDialog(null, "Login bem-sucedido!\nBem-vindo Administrador: " + admin.getNome(), "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            admin.exibirMenu(); // Demonstra polimorfismo via console/pop-up
        } else if (email.equals(vet.getEmail()) && senha.equals(vet.getSenha())) {
            JOptionPane.showMessageDialog(null, "Login bem-sucedido!\nBem-vindo Veterinário: " + vet.getNome(), "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            vet.exibirMenu();
        } else if (email.equals(voluntario.getEmail()) && senha.equals(voluntario.getSenha())) {
            JOptionPane.showMessageDialog(null, "Login bem-sucedido!\nBem-vindo Voluntário: " + voluntario.getNome(), "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            voluntario.exibirMenu();
        } else {
            JOptionPane.showMessageDialog(null, "E-mail ou senha incorretos!", "Erro de Autenticação", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void listarAnimais() {
        StringBuilder sb = new StringBuilder("=== ANIMAIS CADASTRADOS NO ABRIGO ===\n\n");
        for (Animal a : animais) {
            sb.append("ID: ").append(a.getId())
              .append(" | Nome: ").append(a.getNome())
              .append(" | Espécie: ").append(a.getEspecie())
              .append(" | Status: ").append(a.getStatusAdocao())
              .append(" | Crítico: ").append(a.getEstadoCritico() ? "Sim" : "Não")
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Animais Disponíveis", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void executarTestesDeExcecoes() {
        String[] testes = {
            "1. Tentar adotar animal em tratamento crítico (RN3 / RN6)",
            "2. Voluntário tentar registrar vacina (Viola RN4 - Permissão)",
            "3. Veterinário registrar vacinação duplicada na mesma data (RN2)",
            "4. Voluntário tentar aprovar adoção (Viola RN5 - Permissão)",
            "5. Administrador aprovar adoção com sucesso (Fluxo Correto)"
        };

        int testeEscolhido = JOptionPane.showOptionDialog(
            null,
            "Selecione qual regra de negócio deseja testar:",
            "TESTE DE EXCEÇÕES E REGRAS",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.WARNING_MESSAGE,
            null,
            testes,
            testes[0]
        );

        if (testeEscolhido == -1) return;

        Animal animalCritico = animais.get(1); 
        Animal animalDisponivel = animais.get(0); 

        try {
            switch (testeEscolhido) {
                case 0: 
                    if (animalCritico.getEstadoCritico() || !animalCritico.getStatusAdocao().equalsIgnoreCase("Disponível")) {
                        throw new AnimalIndisponivelException("Erro: O animal " + animalCritico.getNome() + " está em tratamento crítico e não pode ser adotado!");
                    }
                    break;

                case 1: 
                    Object usuarioInvalido = voluntario;
                    if (!(usuarioInvalido instanceof Veterinario)) {
                        throw new PermissaoNegadaException("Acesso Negado: Apenas veterinários podem registrar informações médicas!");
                    }
                    break;

                case 2: 
                    String chaveVacina = animalDisponivel.getId() + "-Raiva-27/10/2026";
                    if (historicoVacinas.contains(chaveVacina)) {
                        throw new VacinacaoDuplicadaException("Erro: Vacina contra Raiva já foi aplicada neste animal nesta mesma data!");
                    }
                    historicoVacinas.add(chaveVacina);
                    JOptionPane.showMessageDialog(null, "Primeira aplicação de vacina registrada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

                    throw new VacinacaoDuplicadaException("Erro: Vacina contra Raiva já foi aplicada neste animal nesta mesma data!");

                case 3:
                    Object adminInvalido = voluntario;
                    if (!(adminInvalido instanceof Administrador)) {
                        throw new PermissaoNegadaException("Acesso Negado: Apenas administradores podem concluir e aprovar adoções!");
                    }
                    break;

                case 4:
                    Object adminValido = admin;
                    if (!(adminValido instanceof Administrador)) {
                        throw new PermissaoNegadaException("Acesso Negado!");
                    }
                    if (animalDisponivel.getEstadoCritico()) {
                        throw new AnimalIndisponivelException("Animal indisponível.");
                    }
                    animalDisponivel.setStatusAdocao("Adotado");
                    JOptionPane.showMessageDialog(null, "Adoção do animal " + animalDisponivel.getNome() + " aprovada com sucesso pelo Administrador!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    break;
            }

        } catch (AnimalIndisponivelException | VacinacaoDuplicadaException | PermissaoNegadaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "VIOLAÇÃO DE REGRA DE NEGÓCIO", JOptionPane.ERROR_MESSAGE);
        }
    }
}

