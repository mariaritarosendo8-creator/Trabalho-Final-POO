import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Main extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Button botao = new Button();
        botao.setText("Diga Ola Mundo");
        botao.setOnAction(event -> System.out.println("Ola Mundo"));

        StackPane root = new StackPane();
        root.getChildren().add(botao);

        Scene scene = new Scene(root, 300, 250);

        primaryStage.setTitle("Ola Mundo");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
