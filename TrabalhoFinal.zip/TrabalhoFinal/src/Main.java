import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static List<Animal> animais = new ArrayList<>();
    private static List<String> historicoVacinas = new ArrayList<>();
    
    private static Administrador admin = new Administrador("Adm Niquel", "a1", "admin@abrigo.com", "123");
    private static Veterinario vet = new Veterinario("Doutora Geciara", "v1", "vet@abrigo.com", "123", "CRMV-CE 1234");
    private static Voluntario voluntario = new Voluntario("Maria Rita", "u1", "maria@vol.com", "123");

    public static void main(String[] args) {
        animais.add(new Animal("01", "yoru", "Gato", "SRD", "Pequeno", 2, "Saudável", "10/01/2026", "Disponível", false));
        animais.add(new Animal("02", "Luna", "Cão", "Labrador", "Grande", 4, "Em tratamento", "15/04/2026", "Disponível", true));

        boolean rodando = true;

        while (rodando) {
            String[] opcoesMenuPrincipal = {
                "1. Fazer Login / Área de Perfis",
                "2. Visualizar Animais Disponíveis",
                "3. Testar Regras de Negócio e Exceções",
                "0. Sair do Sistema"
            };

            int escolha = JOptionPane.showOptionDialog(
                null,
                "==================================================\n" +
                "   SISTEMA DE GERENCIAMENTO DE ABRIGOS E RESGATES   \n" +
                "==================================================",
                "MENU PRINCIPAL",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                opcoesMenuPrincipal,
                opcoesMenuPrincipal[0]
            );

            if (escolha == -1 || escolha == 3) {
                JOptionPane.showMessageDialog(null, "Obrigado por utilizar o Sistema de Abrigos!", "Encerrando", JOptionPane.INFORMATION_MESSAGE);
                rodando = false;
                break;
            }

            switch (escolha) {
                case 0:
                    fazerLogin();
                    break;
                case 1:
                    listarAnimais();
                    break;
                case 2:
                    executarTestesDeExcecoes();
                    break;
            }
        }
    }
}
