import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class Main {

    private static List<Animal> animais = new ArrayList<>();

    private static Administrador admin = new Administrador("Diretor Marcos", "a1", "admin@abrigo.com", "123");
    private static Veterinario vet = new Veterinario("Doutora Carla", "v1", "vet@abrigo.com", "123", "CRMV-CE 1234");
    private static Voluntario voluntario = new Voluntario("Ana Silva", "u1", "ana@vol.com", "123");

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Sistema de Abrigos de Animais - Bem-vindo!");

        animais.add(new Animal("01", "Yoru", "Gato", "SRD", "Pequeno", 2, "Saudável", "10/01/2026", "Disponível", false));
        animais.add(new Animal("02", "Luna", "Cão", "Labrador", "Grande", 4, "Em tratamento", "15/04/2026", "Disponível", true));

        while (true) {
            String[] opcoes = {"Administrador", "Veterinário", "Voluntário", "Sair"};
            int escolha = JOptionPane.showOptionDialog(null, "Escolha o tipo de usuário:", "Sistema Abrigo",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opcoes, opcoes[0]);

            if (escolha == 3 || escolha == JOptionPane.CLOSED_OPTION) {
                break;
            }

            String email = JOptionPane.showInputDialog("Digite o e-mail:");
            String senha = JOptionPane.showInputDialog("Digite a senha:");

            Usuario usuario = null;

            switch (escolha) {
                case 0:
                    if (email.equals(admin.getEmail()) && senha.equals(admin.getSenha())) {
                        usuario = admin;
                    }
                    break;
                case 1:
                    if (email.equals(vet.getEmail()) && senha.equals(vet.getSenha())) {
                        usuario = vet;
                    }
                    break;
                case 2:
                    if (email.equals(voluntario.getEmail()) && senha.equals(voluntario.getSenha())) {
                        usuario = voluntario;
                    }
                    break;
            }

            if (usuario != null) {
                usuario.exibirMenu();
            } else {
                JOptionPane.showMessageDialog(null, "Credenciais inválidas. Tente novamente.");
            }
        }

    }
}