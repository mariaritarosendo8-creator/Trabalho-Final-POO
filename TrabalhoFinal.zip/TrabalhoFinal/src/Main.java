import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        SistemaAbrigo sistema = new SistemaAbrigo();

        Animal animal1 = new Animal("1", "Lolla", "Cachorro", "Labrador", "Grande", 3, "Saudável", "13-03-2023", "Disponivel", false);
        Animal animal2 = new Animal("2", "Yoru", "Gato", "Frajola", "Grande", 2, "Saudável", "29-07-2021", "Disponivel", false);

        sistema.adicionarAnimal(animal1);
        sistema.adicionarAnimal(animal2);

        Veterinario vet = new Veterinario("Dr. João", "VET123", "joao.vet@example.com");
        Voluntario voluntario = new Voluntario("Maria", "VOL456");
        Administrador admin = new Administrador("Carlos", "ADM789");
    }
}
