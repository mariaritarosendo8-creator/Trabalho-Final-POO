class Usuarios {
    private String nome;

    public Usuarios(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}

class Voluntario extends Usuarios {
    private 
}
