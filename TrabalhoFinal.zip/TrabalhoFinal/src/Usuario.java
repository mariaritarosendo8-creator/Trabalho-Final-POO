import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

abstract class Usuario {
    protected String nome;
    protected String id;
    protected String email;
    protected String senha;

    public Usuario(String nome, String id, String email, String senha) {
        this.nome = nome;
        this.id = id;  
        this.email = email;
        this.senha = senha;
    }

    public String getNome() { return nome; }
    public String getEmail() { return email; }
    public String getSenha() { return senha; }
    public String getId() { return id; }

    public abstract void exibirMenu();
}

class Voluntario extends Usuario {
    private List<String> historicoParticipacao = new ArrayList<>();
    private List<String> animaisAcompanhados = new ArrayList<>();

    public Voluntario(String nome, String id, String email, String senha) {
        super(nome, id, email, senha);
        this.historicoParticipacao.add("Mutirão de Limpeza do Abrigo (10/01/2026)");
        this.historicoParticipacao.add("Campanha de Vacinação Antirrábica (15/03/2026)");
        this.animaisAcompanhados.add("Luna (Cão - Em tratamento)");
    }

    public void adicionarParticipacao(String evento) {
        this.historicoParticipacao.add(evento);
    }

    public void adicionarAnimalAcompanhado(String animal) {
        this.animaisAcompanhados.add(animal);
    }

    public List<String> getHistoricoParticipacao() { return historicoParticipacao; }
    public List<String> getAnimaisAcompanhados() { return animaisAcompanhados; }

    @Override
    public void exibirMenu() {
        JOptionPane.showMessageDialog(null, "Menu do Voluntário","Voluntário", JOptionPane.INFORMATION_MESSAGE);
    }
}

class Veterinario extends Usuario {
    private String cadastro;

    public Veterinario(String nome, String id, String email, String senha, String cadastro) {
        super(nome, id, email, senha);
        this.cadastro = cadastro;
    }

    public String getCadastro() { return cadastro; }

    @Override
    public void exibirMenu() {
        JOptionPane.showMessageDialog(null, "Menu do Veterinário","Veterinário", JOptionPane.INFORMATION_MESSAGE);
    }
}

class Administrador extends Usuario {
    public Administrador(String nome, String id, String email, String senha) {
        super(nome, id, email, senha);
    }

    @Override
    public void exibirMenu() {
        JOptionPane.showMessageDialog(null, "Menu do Administrador","Administrador", JOptionPane.INFORMATION_MESSAGE);
    }
}