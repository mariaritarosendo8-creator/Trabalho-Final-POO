import java.util.ArrayList;
import java.util.List;

abstract class Usuario {
    private String nome;
    private String id;
    private String email;
    private String senha;

    public Usuario(String nome, String id, String email, String senha) {
        this.nome = nome;
        this.id = id;  
        this.email = email;
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public abstract void exibirMenu();

    public void exibitInfo() {
        System.out.println("Nome: " + nome + "\nE-mail: " + email);
    }
}

class Voluntario extends Usuario {
    private List<String> historicoParticipacao;

    public Voluntario(String nome, String id, String email, String senha) {
        super(nome, id, email, senha);
        this.historicoParticipacao = new ArrayList<>();
    }

    @Override
    public void exibirMenu() {
        System.out.println("Nome: " + getNome() + "\nE-mail: " + getEmail() + "\nVisualizar Animais. \nVisualizar Eventos. \nVisualizar Histórico de Participação.");
    }
}

class Veterinario extends Usuario {
    private String cadastro;

    public Veterinario(String nome, String id, String email, String senha, String cadastro) {
        super(nome, id, email, senha);
        this.cadastro = cadastro;
    }

    @Override
    public void exibirMenu() {
        System.out.println("Nome: " + getNome() + "\nE-mail: " + getEmail() + "\nCadastro: " + cadastro);
    }
}

class Administrador extends Usuario {
    public Administrador(String nome, String id, String email, String senha) {
        super(nome, id, email, senha);
    }

    @Override
    public void exibirMenu() {
        System.out.println("Nome: " + getNome() + "\nE-mail: " + getEmail() + "\nGerenciar Usuários. \nGerenciar Animais. \nGerenciar Eventos.");
    }
}