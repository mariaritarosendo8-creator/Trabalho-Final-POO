public class GerenciarAdocao {
    public void solicitarAdocao(Animal animal, Usuario voluntario) {
        throws AnimalIndisponivel, PermicaoNegadaException, VacinacaoDuplicadaException;
    }

    public void aprovarAdocao(Animal animal, Usuario administrador) {
        throws AnimalIndisponivel, PermicaoNegadaException, VacinacaoDuplicadaException;
    }
}

